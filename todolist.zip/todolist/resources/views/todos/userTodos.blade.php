@extends('master')


@section('content')

    <div class="bg-white border mb-3 p-3">
        <div class="text-center">
            <h2>List of my Todos</h2>
        </div>
    </div>

    <div class="bg-white border p-4">
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Deadline</th>
                <th colspan="5" class="text-center">Actions</th>
            </tr>
            </thead>
            <tbody>
            @foreach( $todos as $todo)
                <tr>
                    <th scope="row">{{ $todo->id  }}</th>
                    <td>{{ $todo->title  }}</td>
                    <td>{{ date('H:i d-m-Y', strtotime($todo->deadline_date))  }}</td>
                    <td class="text-left">
                    {{--@if($todo->is_completed)--}}
                        {{--<td><a href="/todos/complete-toggle/{{ $todo->id }}" class="btn btn-sm btn-danger pl-3 pr-3"><i class="fas fa-times pl-1 pr-1"></i></a></td>--}}
                    {{--@else--}}
                        {{--<td><a href="/todos/complete-toggle/{{ $todo->id }}" class="btn btn-sm btn-success pl-3 pr-3"><i class="fas fa-check"></i></a></td>--}}
                    {{--@endif--}}
                    <td><complete-toggle todo-id="{{ $todo->id }}" completed="{{ $todo->is_completed }}"></complete-toggle></td>
                    <td><a href="/todos/edit/{{ $todo->id }}" class="btn btn-sm btn-secondary"><i class="far fa-edit"></i></a></td>
                    <td><show-todo todo-id="{{ $todo->id }}"></show-todo></td>
                    <td><a href="javascript:;" class="btn btn-sm btn-danger delete-todo"><i class="far fa-trash-alt"></i></a></td>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection
