@extends('master')


@section('content')

    <div class="bg-white border mb-3 p-3">
        <div class="text-center">
            @isset($category)
                <h2>{{ $category->name }} category todos:</h2>
            @endisset
            @isset($difficulty)
                <h2>{{ $difficulty->name }} difficulty todos:</h2>
            @endisset
            @isset($all)
                <h2>List of all todos:</h2>
            @endisset
            @isset($completed)
                <h2>List of completed todos:</h2>
            @endisset
            @isset($project)
                <h2>{{ $project->name }} todos:</h2>
            @endisset
        </div>
    </div>

    @if(!count($todos))
        <div class="bg-white border border-danger p-4">
            <h1 class="text-secondary text-center">
                Sorry the are no todos in this page!
            </h1>
        </div>
    @else

    <div class="bg-white border p-4">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Deadline</th>
                    <th colspan="2">User</th>
                </tr>
                </thead>
                <tbody>
                @foreach( $todos as $todo)
                    <tr>
                        <th scope="row">{{ $todo->id  }}</th>
                        <td>{{ $todo->title  }}</td>
                        <td>{{ date('H:i d-m-Y', strtotime($todo->deadline_date))  }}</td>
                        <td>{{ $todo->user->name }}</td>
                        <td>
                            <show-todo todo-id="{{ $todo->id }}"></show-todo>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        @endif
    </div>

@endsection