@extends('master')


@section('content')

    <div class="col-8 m-auto text-center bg-white border p-4">
        <div class="border-bottom mb-4">
            <h1 class="text-dark">Todo details: </h1>
        </div>

        <table class="table table-striped table-borderless text-left">
            <tbody>
                <tr>
                    <th><i class="fas fa-id-card pr-4 pl-5"></i> Id:</th>
                    <td>{{ $todo->id  }}</td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-heading pr-4 pl-5"></i> Title:</th>
                    <td>{{ $todo->title  }}</td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-feather-alt pr-4 pl-5"></i> Description:</th>
                    <td>{{ $todo->description  }}</td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-dumbbell pr-4 pl-5"></i> Difficulty:</th>
                    <td>{{ $todo->difficulty->name  }}</td>
                </tr>
                <tr>
                    <th scope="row"><i class="fab fa-cuttlefish pr-4 pl-5"></i> Category:</th>
                    <td>{{ $todo->category->name  }}</td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-user pr-4 pl-5"></i> User:</th>
                    <td>{{ $todo->user->name  }}</td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-stopwatch pr-4 pl-5"></i> Deadline:</th>
                    <td>{{ date('d, F Y H:i ', strtotime($todo->deadline_date))  }}</td>
                </tr>
                <tr class="border-bottom">
                    <th scope="row"><i class="fas fa-check-circle pr-4 pl-5"></i> Completion:</th>
                    <td>{{ ($todo->is_completed ) ? 'Completed' : 'Not completed'}}</td>
                </tr>
            </tbody>
        </table>
    </div>

@endsection