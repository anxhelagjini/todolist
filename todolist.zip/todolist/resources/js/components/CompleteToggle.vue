<template>
    <div>

        <button @click="completeToggle" class="btn btn-sm btn-danger pl-3 pr-3" v-if="isCompleted"><i class="fas fa-times pl-1 pr-1"></i></button>
        <button @click="completeToggle" class="btn btn-sm btn-success pl-3 pr-3" v-else><i class="fas fa-check"></i></button>

    </div>
</template>

<script>
    export default {
        props: ['todoId', 'completed'],
        data() {
            return {
                isCompleted: (this.completed == 1) ? true : false,
            }
        },
        methods: {
            completeToggle() {
                var that = this
                axios.get('/todos/complete-toggle/' + this.todoId).then(function (response) {
                    that.isCompleted = response.data.is_completed
                })
            }
        }
    }
</script>