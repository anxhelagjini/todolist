<template>
    <div>
        <button class="btn btn-sm btn-info" @click="showModal"><i class="far fa-eye"></i></button>
        <modal
            :name="'show_todo'+ todoId"
            height="auto"
            width="50%"
            :scrollable="true"
            :adaptive="true"
        >

            <div class="m-auto text-center bg-white border p-4">
                <div class="border-bottom mb-4">
                    <h1 class="text-dark">Todo details: </h1>
                </div>
                <table class="table table-striped table-borderless text-left">
                    <tbody>
                    <tr>
                        <th><i class="fas fa-id-card pr-4 pl-5"></i> Id:</th>
                        <td>{{ todo.id  }}</td>
                    </tr>
                    <tr>
                        <th scope="row"><i class="fas fa-heading pr-4 pl-5"></i> Title:</th>
                        <td>{{ todo.title  }}</td>
                    </tr>
                    <tr>
                        <th scope="row"><i class="fas fa-feather-alt pr-4 pl-5"></i> Description:</th>
                        <td>{{ todo.description  }}</td>
                    </tr>
                    <tr>
                        <th scope="row"><i class="fas fa-dumbbell pr-4 pl-5"></i> Difficulty:</th>
                        <td v-if="todo.difficulty">{{ todo.difficulty.name  }}</td>
                    </tr>
                    <tr>
                        <th scope="row"><i class="fab fa-cuttlefish pr-4 pl-5"></i> Category:</th>
                        <td v-if="todo.category">{{ todo.category.name  }}</td>
                    </tr>
                    <tr>
                        <th scope="row"><i class="fas fa-project-diagram pr-4 pl-5"></i> Project:</th>
                        <td v-if="todo.project">{{ todo.project.name  }}</td>
                    </tr>
                    <tr>
                        <th scope="row"><i class="fas fa-user pr-4 pl-5"></i> User:</th>
                        <td v-if="todo.user">{{ todo.user.name  }}</td>
                    </tr>
                    <tr>
                        <th scope="row"><i class="fas fa-stopwatch pr-4 pl-5"></i> Deadline:</th>
                        <td>{{ todo.deadline_date  }}</td>
                    </tr>
                    <tr class="border-bottom">
                        <th scope="row"><i class="fas fa-check-circle pr-4 pl-5"></i> Completion:</th>
                        <td>{{ todo.is_completed ? 'Completed' : 'Not completed'}}</td>
                    </tr>
                    </tbody>
                </table>
            </div>

        </modal>
    </div>
</template>

<script>
    export default {
        props: ['todoId'],
        data() {
            return {
                todo: {},
            }
        },
        methods: {
            async showModal() {
                await this.getTodo()
                this.$modal.show('show_todo' + this.todoId)
            },
            getTodo() {
                var that = this
                axios.get('/todos/show/' + this.todoId).then(function (response) {
                    that.todo = response.data
                })
            }
        }
    }
</script>
