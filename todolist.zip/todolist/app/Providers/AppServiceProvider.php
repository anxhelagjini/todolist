<?php

namespace App\Providers;

use App\Category;
use App\Difficulty;
use App\Project;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('master', function ($view) {
            $categories = Category::all();
            $difficulties = Difficulty::all();
            $projects = Project::all();

            $view->with(compact(['categories', 'difficulties', 'projects']));
        });
    }
}
