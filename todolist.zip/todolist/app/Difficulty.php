<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Difficulty extends Model
{
    protected $fillable = [
        'name'
    ];

    public function todos()
    {
        return $this->hasMany(Todo::class, 'difficulty_id');
    }
}
