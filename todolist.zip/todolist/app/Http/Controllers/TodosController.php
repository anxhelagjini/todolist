<?php

namespace App\Http\Controllers;

use App\Category;
use App\Difficulty;
use App\Project;
use App\Todo;
use App\User;
use Illuminate\Http\Request;

class TodosController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $todos = Todo::all();

        $all = true;

        return view('todos.index', compact(['todos', 'all']));
    }

    public function finishedTodos()
    {
        $todos = Todo::where('is_completed', '=', 1)->get();

        $completed = true;

        return view('todos.index', compact(['todos', 'completed']));
    }

    public function userTodos($userId)
    {
        $user = User::find($userId);
        $todos = $user->todos;

        return view('todos.userTodos', compact('todos'));
    }

    public function categoryTodos($categoryId)
    {
        $category = Category::find($categoryId);
        $todos = $category->todos;

        return view('todos.index', compact(['todos', 'category']));
    }

    public function difficultyTodos($difficultyId)
    {
        $difficulty = Difficulty::find($difficultyId);
        $todos = $difficulty->todos;

        return view('todos.index', compact(['todos', 'difficulty']));
    }

    public function projectTodos($projectId)
    {
        $project = Project::find($projectId);

        $todos =$project->todos;

        return view('todos.index', compact(['todos', 'project']));
    }

    public function show($todoId)
    {
        $todo = Todo::find($todoId);

        $todo->category;

        $todo->difficulty;

        $todo->user;

        $todo->project;

        return $todo;
    }

    public function create()
    {
        $difficulties = Difficulty::all();
        $categories = Category::all();
        $projects = Project::all();

        return view('todos.create', compact(['difficulties', 'categories', 'projects']));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
            'difficulty_id' => 'required',
            'category_id' => 'required',
            'project_id' => 'required',
            'deadline_date' => 'required',
        ]);
        $date = date_create($request->deadline);

        Todo::create([
            'title' => $request->title,
            'description' => $request->description,
            'difficulty_id' => $request->difficulty,
            'user_id' => auth()->id(),
            'category_id' => $request->category,
            'project_id' => $request->project,
            'is_completed' => 0,
            'deadline_date' => date_format($date, 'Y-m-d H:i:s'),
        ]);

        return redirect('/');
    }

    public function edit($todoId)
    {
        $todo = Todo::find($todoId);
        $difficulties = Difficulty::all();
        $categories = Category::all();
        $projects = Project::all();

        return view('todos.edit', compact(['todo', 'difficulties', 'categories', 'projects']));
    }

    public function update($todoId, Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
            'difficulty_id' => 'required',
            'category_id' => 'required',
            'project_id' => 'required',
            'deadline_date' => 'required',
        ]);
        $todo = Todo::find($todoId);
        $todo->update([
            'title' => $request->title,
            'description' => $request->description,
            'difficulty_id' => $request->difficulty,
            'category_id' => $request->category,
            'project_id' => $request->project,
            'deadline_date' => $request->deadline,
        ]);

        return redirect('/');
    }

    public function completedToggle($todoId)
    {
        $todo = Todo::find($todoId);

        if ($todo->is_completed) {
            $todo->is_completed = false;
        } else {
            $todo->is_completed = true;
        }

        $todo->save();

        return $todo;
    }

    public function delete($todoId)
    {

        Todo::destroy($todoId);

        return redirect('/');
    }
}
