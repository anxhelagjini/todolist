<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $fillable = [
        'name'
    ];

    public function todos()
    {
        return $this->hasMany(Todo::class, 'project_id');
    }
}
