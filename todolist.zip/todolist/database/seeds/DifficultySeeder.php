<?php

use Illuminate\Database\Seeder;

class DifficultySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $easy = \App\Difficulty::create([
            'name' => 'Easy',
        ]);

        $medium = \App\Difficulty::create([
            'name' => 'Medium',
        ]);

        $hard = \App\Difficulty::create([
            'name' => 'Hard',
        ]);

    }
}