<?php

use Illuminate\Database\Seeder;

class ProjectSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $project1 = \App\Project::create([
            'name' => 'Project 1',
        ]);

        $porject2 = \App\Project::create([
            'name' => 'Project 2',
        ]);

        $porject3 = \App\Project::create([
            'name' => 'Project 3',
        ]);

    }
}