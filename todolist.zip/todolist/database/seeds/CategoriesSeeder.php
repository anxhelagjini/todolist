<?php

use Illuminate\Database\Seeder;

class CategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $work = \App\Category::create([
            'name' => 'Work',
        ]);

        $house = \App\Category::create([
            'name' => 'House',
        ]);

        $fun = \App\Category::create([
            'name' => 'Fun',
        ]);

        $hard = \App\Category::create([
            'name' => 'Family',
        ]);

        $hard = \App\Category::create([
            'name' => 'Other',
        ]);

    }

}