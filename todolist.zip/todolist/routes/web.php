<?php


Route::get('/', 'TodosController@index');

Route::get('/todos/category/{categoryId}', 'TodosController@categoryTodos')->name('categoryTodos');

Route::get('/todos/difficulty/{difficultyId}', 'TodosController@difficultyTodos')->name('difficultyTodos');

Route::get('todos/project/{projectId}', 'TodosController@projectTodos')->name('projectTodos');

Route::get('/user-todos/{userId}', 'TodosController@userTodos');

Route::get('/completed-todos', 'TodosController@finishedTodos');

Route::get('/todos/show/{todoId}', 'TodosController@show');

Route::get('/todos/create', 'TodosController@create');

Route::post('/todos/store', 'TodosController@store');

Route::get('/todos/edit/{todoId}', 'TodosController@edit');

Route::post('/todos/update/{todoId}', 'TodosController@update');

Route::get('/todos/delete/{todoId}', 'TodosController@delete');

Route::get('/todos/complete-toggle/{todoId}', 'TodosController@completedToggle');

Route::get('/login', 'LoginController@index')->name('login');

Route::post('/login', 'LoginController@store');

Route::get('/register', 'LoginController@create')->name('register');

Route::post('/register', 'LoginController@storeRegistration');

Route::get('/logout', 'LoginController@destroy');