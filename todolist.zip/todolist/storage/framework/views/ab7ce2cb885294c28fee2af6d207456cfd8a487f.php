<?php $__env->startSection('content'); ?>

    <div class="bg-white border p-4">
        <div class="text-center">
            <h1><i class="fas fa-edit"></i> Edit Todo</h1>
            <hr>
        </div>

        <form method="post" action="/todos/update/<?php echo e($todo->id); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="title"><i class="fas fa-heading pr-1"></i> Title:</label>
                <input type="text" name="title" class="form-control" value="<?php echo e($todo->title); ?>" placeholder="Enter todo title">
            </div>
            <div class="form-group">
                <label for="description"><i class="fas fa-feather-alt pr-1"></i> Description:</label>
                <textarea name="description" class="form-control" placeholder="Enter todo description"><?php echo e($todo->description); ?></textarea>
            </div>

            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="difficulty"><i class="fas fa-project-diagram pr-1"></i> Project:</label>
                        <select name="project" class="form-control">
                            <option value="null" disabled selected>Select the difficulty</option>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($project->id === $todo->project_id): ?>
                                    <option value="<?php echo e($project->id); ?>" selected><?php echo e($project->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="category"><i class="fab fa-cuttlefish pr-1"></i> Category:</label>
                        <select name="category" class="form-control">
                            <option value="null" disabled>Select category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->id === $todo->category_id): ?>
                                    <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="difficulty"><i class="fas fa-dumbbell pr-1"></i> Difficulty:</label>
                        <select name="difficulty" class="form-control">
                            <option value="null" disabled selected>Select the difficulty</option>
                            <?php $__currentLoopData = $difficulties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $difficulty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($difficulty->id === $todo->difficulty_id): ?>
                                    <option value="<?php echo e($difficulty->id); ?>" selected><?php echo e($difficulty->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($difficulty->id); ?>"><?php echo e($difficulty->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="difficulty"><i class="fas fa-stopwatch pr-1"></i> Deadline:</label>
                        <input type="datetime-local" name="deadline" class="form-control" value="<?php echo e(date('Y-m-d\TH:i:s', strtotime($todo->deadline_date))); ?>">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col"></div>
                <div class="col-2">
                    <button type="submit" class="btn btn-danger btn-block mt-2">Submit</button>
                </div>
            </div>

        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/todolist/resources/views/todos/edit.blade.php ENDPATH**/ ?>