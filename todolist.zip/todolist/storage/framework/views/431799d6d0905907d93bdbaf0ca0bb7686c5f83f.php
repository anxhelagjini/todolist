<?php $__env->startSection('content'); ?>

    <div class="bg-white border mb-3 p-3">
        <div class="text-center">
            <?php if(isset($category)): ?>
                <h2><?php echo e($category->name); ?> category todos:</h2>
            <?php endif; ?>
            <?php if(isset($difficulty)): ?>
                <h2><?php echo e($difficulty->name); ?> difficulty todos:</h2>
            <?php endif; ?>
            <?php if(isset($all)): ?>
                <h2>List of all todos:</h2>
            <?php endif; ?>
            <?php if(isset($completed)): ?>
                <h2>List of completed todos:</h2>
            <?php endif; ?>
            <?php if(isset($project)): ?>
                <h2><?php echo e($project->name); ?> todos:</h2>
            <?php endif; ?>
        </div>
    </div>

    <?php if(!count($todos)): ?>
        <div class="bg-white border border-danger p-4">
            <h1 class="text-secondary text-center">
                Sorry the are no todos in this page!
            </h1>
        </div>
    <?php else: ?>

    <div class="bg-white border p-4">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Deadline</th>
                    <th colspan="2">User</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($todo->id); ?></th>
                        <td><?php echo e($todo->title); ?></td>
                        <td><?php echo e(date('H:i d-m-Y', strtotime($todo->deadline_date))); ?></td>
                        <td><?php echo e($todo->user->name); ?></td>
                        <td>
                            <show-todo todo-id="<?php echo e($todo->id); ?>"></show-todo>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/todolist/resources/views/todos/index.blade.php ENDPATH**/ ?>