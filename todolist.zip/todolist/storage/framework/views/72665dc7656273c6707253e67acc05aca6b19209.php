<?php $__env->startSection('content'); ?>

    <div class="col-8 m-auto text-center bg-white border p-4">
        <div class="border-bottom mb-4">
            <h1 class="text-dark">Todo details: </h1>
        </div>

        <table class="table table-striped table-borderless text-left">
            <tbody>
                <tr>
                    <th><i class="fas fa-id-card pr-4 pl-5"></i> Id:</th>
                    <td><?php echo e($todo->id); ?></td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-heading pr-4 pl-5"></i> Title:</th>
                    <td><?php echo e($todo->title); ?></td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-feather-alt pr-4 pl-5"></i> Description:</th>
                    <td><?php echo e($todo->description); ?></td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-dumbbell pr-4 pl-5"></i> Difficulty:</th>
                    <td><?php echo e($todo->difficulty->name); ?></td>
                </tr>
                <tr>
                    <th scope="row"><i class="fab fa-cuttlefish pr-4 pl-5"></i> Category:</th>
                    <td><?php echo e($todo->category->name); ?></td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-user pr-4 pl-5"></i> User:</th>
                    <td><?php echo e($todo->user->name); ?></td>
                </tr>
                <tr>
                    <th scope="row"><i class="fas fa-stopwatch pr-4 pl-5"></i> Deadline:</th>
                    <td><?php echo e(date('d, F Y H:i ', strtotime($todo->deadline_date))); ?></td>
                </tr>
                <tr class="border-bottom">
                    <th scope="row"><i class="fas fa-check-circle pr-4 pl-5"></i> Completion:</th>
                    <td><?php echo e(($todo->is_completed ) ? 'Completed' : 'Not completed'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/todolist/resources/views/todos/show.blade.php ENDPATH**/ ?>