<?php $__env->startSection('content'); ?>

    <div class="bg-white border mb-3 p-3">
        <div class="text-center">
            <h2>List of my Todos</h2>
        </div>
    </div>

    <div class="bg-white border p-4">
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Deadline</th>
                <th colspan="5" class="text-center">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($todo->id); ?></th>
                    <td><?php echo e($todo->title); ?></td>
                    <td><?php echo e(date('H:i d-m-Y', strtotime($todo->deadline_date))); ?></td>
                    <td class="text-left">
                    
                        
                    
                        
                    
                    <td><complete-toggle todo-id="<?php echo e($todo->id); ?>" completed="<?php echo e($todo->is_completed); ?>"></complete-toggle></td>
                    <td><a href="/todos/edit/<?php echo e($todo->id); ?>" class="btn btn-sm btn-secondary"><i class="far fa-edit"></i></a></td>
                    <td><show-todo todo-id="<?php echo e($todo->id); ?>"></show-todo></td>
                    <td><a href="javascript:;" class="btn btn-sm btn-danger delete-todo"><i class="far fa-trash-alt"></i></a></td>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/todolist/resources/views/todos/userTodos.blade.php ENDPATH**/ ?>