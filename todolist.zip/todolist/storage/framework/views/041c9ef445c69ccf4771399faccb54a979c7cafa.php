<?php $__env->startSection('content'); ?>

    <div class="col-6 m-auto p-4 bg-white border">
        <form method="post">

            <?php echo e(csrf_field()); ?>


            <div class="text-center mb-4">
                <h1>Register</h1>
                <hr>
            </div>

            <div class="form-label-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" placeholder="Name" required>
            </div>

            <div class="form-label-group">
                <label for="email">Email address</label>
                <input type="email" name="email" class="form-control" placeholder="Email address" required>
            </div>

            <div class="form-label-group">
                <label for="birthday">Birthday</label>
                <input type="date" name="birthday" class="form-control" placeholder="YYYY-MM-DD" required>
            </div>

            <div class="form-label-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>

            <div class="form-label-group">
                <label for="password_confirmation">Password Confirmation</label>
                <input type="password" name="password_confirmation" class="form-control" placeholder="Password confirmation" required>
            </div>

            <button class="btn btn-lg btn-danger btn-block mt-4" type="submit">Sign up</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maksibajo/code/todolist/resources/views/login/register.blade.php ENDPATH**/ ?>